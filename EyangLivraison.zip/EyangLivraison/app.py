import streamlit as st
import pandas as pd
import json
from datetime import datetime
import os

# Initialize data files
DATA_DIR = "data"
PRODUCTS_FILE = os.path.join(DATA_DIR, "products.json")
ORDERS_FILE = os.path.join(DATA_DIR, "orders.json")
SHOPPING_LISTS_FILE = os.path.join(DATA_DIR, "shopping_lists.json")
SETTINGS_FILE = os.path.join(DATA_DIR, "settings.json")

# Create data directory if it doesn't exist
if not os.path.exists(DATA_DIR):
    os.makedirs(DATA_DIR)

# Multi-language translations
TRANSLATIONS = {
    "en": {
        "title": "Eyang Livraison",
        "tagline": "Your trusted 24/7 delivery service for all your basic necessities",
        "available": "Available 24/7 - Every Day",
        "language": "Language",
        "home": "Home",
        "products": "Products",
        "cart": "My Cart",
        "shopping_list": "Custom Shopping List",
        "admin": "Admin Panel",
        "search": "Search products...",
        "all_categories": "All Categories",
        "add_to_cart": "Add to Cart",
        "price": "Price",
        "category": "Category",
        "in_stock": "In Stock",
        "out_of_stock": "Out of Stock",
        "your_cart": "Your Shopping Cart",
        "empty_cart": "Your cart is empty",
        "total": "Total",
        "place_order": "Place Order",
        "customer_info": "Customer Information",
        "full_name": "Full Name",
        "phone": "Phone Number",
        "address": "Delivery Address",
        "additional_notes": "Additional Notes (Optional)",
        "order_success": "Order Placed Successfully!",
        "contact_message": "An agent will contact you in less than 5 minutes",
        "payment_method": "Payment Method: Cash on Delivery",
        "custom_list_title": "Submit Your Custom Shopping List",
        "custom_list_desc": "Can't find what you need? Submit your custom shopping list and we'll get it for you!",
        "list_items": "Items you need (one per line)",
        "submit_list": "Submit Shopping List",
        "list_success": "Shopping list submitted successfully!",
        "admin_login": "Admin Login",
        "password": "Password",
        "login": "Login",
        "logout": "Logout",
        "manage_products": "Manage Products",
        "view_orders": "View Orders",
        "view_shopping_lists": "View Shopping Lists",
        "settings": "Settings",
        "add_product": "Add New Product",
        "product_name": "Product Name",
        "description": "Description",
        "stock_status": "Stock Status",
        "save": "Save",
        "edit": "Edit",
        "delete": "Delete",
        "cancel": "Cancel",
        "order_id": "Order #",
        "customer": "Customer",
        "date": "Date",
        "status": "Status",
        "pending": "Pending",
        "confirmed": "Confirmed",
        "delivered": "Delivered",
        "items": "Items",
        "quantity": "Quantity",
        "remove": "Remove",
        "update_cart": "Update Cart",
        "continue_shopping": "Continue Shopping",
    },
    "fr": {
        "title": "Eyang Livraison",
        "tagline": "Votre service de livraison de confiance 24/7 pour tous vos produits de première nécessité",
        "available": "Disponible 24/7 - Tous les jours",
        "language": "Langue",
        "home": "Accueil",
        "products": "Produits",
        "cart": "Mon Panier",
        "shopping_list": "Liste de Courses Personnalisée",
        "admin": "Panneau Admin",
        "search": "Rechercher des produits...",
        "all_categories": "Toutes les Catégories",
        "add_to_cart": "Ajouter au Panier",
        "price": "Prix",
        "category": "Catégorie",
        "in_stock": "En Stock",
        "out_of_stock": "Rupture de Stock",
        "your_cart": "Votre Panier",
        "empty_cart": "Votre panier est vide",
        "total": "Total",
        "place_order": "Passer la Commande",
        "customer_info": "Informations Client",
        "full_name": "Nom Complet",
        "phone": "Numéro de Téléphone",
        "address": "Adresse de Livraison",
        "additional_notes": "Notes Additionnelles (Optionnel)",
        "order_success": "Commande Passée avec Succès!",
        "contact_message": "Un agent vous contactera dans moins de 5 minutes",
        "payment_method": "Méthode de Paiement: Paiement à la Livraison",
        "custom_list_title": "Soumettre Votre Liste de Courses Personnalisée",
        "custom_list_desc": "Vous ne trouvez pas ce dont vous avez besoin? Soumettez votre liste et nous l'obtiendrons pour vous!",
        "list_items": "Articles dont vous avez besoin (un par ligne)",
        "submit_list": "Soumettre la Liste",
        "list_success": "Liste de courses soumise avec succès!",
        "admin_login": "Connexion Admin",
        "password": "Mot de Passe",
        "login": "Connexion",
        "logout": "Déconnexion",
        "manage_products": "Gérer les Produits",
        "view_orders": "Voir les Commandes",
        "view_shopping_lists": "Voir les Listes de Courses",
        "settings": "Paramètres",
        "add_product": "Ajouter un Nouveau Produit",
        "product_name": "Nom du Produit",
        "description": "Description",
        "stock_status": "État du Stock",
        "save": "Enregistrer",
        "edit": "Modifier",
        "delete": "Supprimer",
        "cancel": "Annuler",
        "order_id": "Commande #",
        "customer": "Client",
        "date": "Date",
        "status": "Statut",
        "pending": "En Attente",
        "confirmed": "Confirmé",
        "delivered": "Livré",
        "items": "Articles",
        "quantity": "Quantité",
        "remove": "Retirer",
        "update_cart": "Mettre à Jour le Panier",
        "continue_shopping": "Continuer les Achats",
    }
}

# Helper functions for data management
def load_json(file_path, default):
    if os.path.exists(file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return default
    return default

def save_json(file_path, data):
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def initialize_default_data():
    # Initialize products if not exists
    if not os.path.exists(PRODUCTS_FILE):
        default_products = [
            {"id": 1, "name": "Rice (1kg)", "name_fr": "Riz (1kg)", "price": 500, "category": "Food", "category_fr": "Nourriture", "description": "Premium quality rice", "description_fr": "Riz de qualité supérieure", "in_stock": True},
            {"id": 2, "name": "Cooking Oil (1L)", "name_fr": "Huile de Cuisine (1L)", "price": 800, "category": "Food", "category_fr": "Nourriture", "description": "Vegetable cooking oil", "description_fr": "Huile végétale", "in_stock": True},
            {"id": 3, "name": "Sugar (1kg)", "name_fr": "Sucre (1kg)", "price": 600, "category": "Food", "category_fr": "Nourriture", "description": "White granulated sugar", "description_fr": "Sucre blanc granulé", "in_stock": True},
            {"id": 4, "name": "Salt (500g)", "name_fr": "Sel (500g)", "price": 200, "category": "Food", "category_fr": "Nourriture", "description": "Iodized table salt", "description_fr": "Sel de table iodé", "in_stock": True},
            {"id": 5, "name": "Soap Bar", "name_fr": "Savon", "price": 300, "category": "Personal Care", "category_fr": "Soins Personnels", "description": "Antibacterial soap", "description_fr": "Savon antibactérien", "in_stock": True},
            {"id": 6, "name": "Toothpaste", "name_fr": "Dentifrice", "price": 400, "category": "Personal Care", "category_fr": "Soins Personnels", "description": "Mint toothpaste", "description_fr": "Dentifrice à la menthe", "in_stock": True},
            {"id": 7, "name": "Laundry Detergent", "name_fr": "Détergent à Lessive", "price": 1200, "category": "Household", "category_fr": "Ménage", "description": "Washing powder 500g", "description_fr": "Poudre à laver 500g", "in_stock": True},
            {"id": 8, "name": "Toilet Paper (4 rolls)", "name_fr": "Papier Toilette (4 rouleaux)", "price": 1000, "category": "Household", "category_fr": "Ménage", "description": "Soft toilet tissue", "description_fr": "Papier toilette doux", "in_stock": True},
        ]
        save_json(PRODUCTS_FILE, default_products)
    
    # Initialize orders if not exists
    if not os.path.exists(ORDERS_FILE):
        save_json(ORDERS_FILE, [])
    
    # Initialize shopping lists if not exists
    if not os.path.exists(SHOPPING_LISTS_FILE):
        save_json(SHOPPING_LISTS_FILE, [])
    
    # Initialize settings if not exists
    if not os.path.exists(SETTINGS_FILE):
        default_settings = {
            "admin_password": "admin123",
            "currency": "FCFA",
            "contact_phone": "+237 XXX XXX XXX",
            "contact_email": "contact@eyanglivraison.com"
        }
        save_json(SETTINGS_FILE, default_settings)

# Initialize data
initialize_default_data()

# Initialize session state
if 'language' not in st.session_state:
    st.session_state.language = 'en'

if 'cart' not in st.session_state:
    st.session_state.cart = {}

if 'admin_logged_in' not in st.session_state:
    st.session_state.admin_logged_in = False

if 'page' not in st.session_state:
    st.session_state.page = 'home'

# Get current language translations
def t(key):
    return TRANSLATIONS[st.session_state.language].get(key, key)

# Page configuration
st.set_page_config(
    page_title="Eyang Livraison - 24/7 Delivery Service",
    page_icon="🛒",
    layout="wide"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        text-align: center;
        padding: 1rem;
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 10px;
        margin-bottom: 2rem;
    }
    .available-badge {
        background-color: #10b981;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 20px;
        display: inline-block;
        font-weight: bold;
        margin-top: 0.5rem;
    }
    .product-card {
        border: 1px solid #e5e7eb;
        border-radius: 10px;
        padding: 1rem;
        margin-bottom: 1rem;
        background-color: white;
    }
    .success-message {
        background-color: #d1fae5;
        border: 2px solid #10b981;
        border-radius: 10px;
        padding: 1.5rem;
        margin: 1rem 0;
    }
    .notification-badge {
        background-color: #ef4444;
        color: white;
        border-radius: 50%;
        padding: 0.25rem 0.5rem;
        font-size: 0.75rem;
        font-weight: bold;
    }
</style>
""", unsafe_allow_html=True)

# Header
st.markdown(f"""
<div class="main-header">
    <h1>🛒 {t('title')}</h1>
    <p>{t('tagline')}</p>
    <div class="available-badge">⏰ {t('available')}</div>
</div>
""", unsafe_allow_html=True)

# Language selector in sidebar
with st.sidebar:
    st.subheader(f"🌐 {t('language')}")
    language_options = {"English": "en", "Français": "fr"}
    current_lang_name = "English" if st.session_state.language == "en" else "Français"
    selected_lang = st.selectbox("", list(language_options.keys()), index=list(language_options.values()).index(st.session_state.language), label_visibility="collapsed")
    
    if language_options[selected_lang] != st.session_state.language:
        st.session_state.language = language_options[selected_lang]
        st.rerun()
    
    st.divider()
    
    # Navigation
    st.subheader("📍 Navigation")
    
    # Show notification badge for new orders in admin
    admin_badge = ""
    if st.session_state.admin_logged_in:
        orders = load_json(ORDERS_FILE, [])
        shopping_lists = load_json(SHOPPING_LISTS_FILE, [])
        unseen_orders = len([o for o in orders if not o.get('seen', False)])
        unseen_lists = len([l for l in shopping_lists if not l.get('seen', False)])
        total_unseen = unseen_orders + unseen_lists
        if total_unseen > 0:
            admin_badge = f" 🔴 ({total_unseen})"
    
    menu_items = [
        ("🏠 " + t('home'), 'home'),
        ("🛍️ " + t('products'), 'products'),
        ("🛒 " + t('cart') + f" ({len(st.session_state.cart)})", 'cart'),
        ("📝 " + t('shopping_list'), 'shopping_list'),
        ("⚙️ " + t('admin') + admin_badge, 'admin'),
    ]
    
    for label, page in menu_items:
        if st.button(label, use_container_width=True, type="primary" if st.session_state.page == page else "secondary"):
            st.session_state.page = page
            st.rerun()

# Main content area
if st.session_state.page == 'home':
    st.header("🏠 " + t('home'))
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("✨ Welcome to Eyang Livraison!" if st.session_state.language == 'en' else "✨ Bienvenue chez Eyang Livraison!")
        st.write("""
        We provide fast and reliable delivery of basic life necessities right to your doorstep.
        """ if st.session_state.language == 'en' else """
        Nous fournissons une livraison rapide et fiable des produits de première nécessité directement à votre porte.
        """)
        
        st.info("💰 " + t('payment_method'))
        
        if st.button("🛍️ " + ("Start Shopping" if st.session_state.language == 'en' else "Commencer les Achats"), use_container_width=True):
            st.session_state.page = 'products'
            st.rerun()
    
    with col2:
        st.subheader("📞 " + ("Contact Us" if st.session_state.language == 'en' else "Contactez-nous"))
        settings = load_json(SETTINGS_FILE, {})
        st.write(f"📱 {settings.get('contact_phone', '+237 XXX XXX XXX')}")
        st.write(f"✉️ {settings.get('contact_email', 'contact@eyanglivraison.com')}")
        st.write("⏰ " + t('available'))

elif st.session_state.page == 'products':
    st.header("🛍️ " + t('products'))
    
    products = load_json(PRODUCTS_FILE, [])
    
    # Search and filter
    col1, col2 = st.columns([3, 1])
    with col1:
        search = st.text_input("🔍", placeholder=t('search'), label_visibility="collapsed")
    
    with col2:
        categories = list(set([p.get('category_fr' if st.session_state.language == 'fr' else 'category', 'Other') for p in products]))
        categories.insert(0, t('all_categories'))
        selected_category = st.selectbox("Category", categories, label_visibility="collapsed")
    
    # Filter products
    filtered_products = products
    if search:
        filtered_products = [p for p in filtered_products if search.lower() in p.get('name_fr' if st.session_state.language == 'fr' else 'name', '').lower()]
    
    if selected_category != t('all_categories'):
        filtered_products = [p for p in filtered_products if p.get('category_fr' if st.session_state.language == 'fr' else 'category') == selected_category]
    
    # Display products
    if len(filtered_products) == 0:
        st.info("No products found" if st.session_state.language == 'en' else "Aucun produit trouvé")
    else:
        cols = st.columns(3)
        for idx, product in enumerate(filtered_products):
            with cols[idx % 3]:
                with st.container():
                    st.markdown(f"### {product.get('name_fr' if st.session_state.language == 'fr' else 'name')}")
                    st.write(product.get('description_fr' if st.session_state.language == 'fr' else 'description'))
                    
                    settings = load_json(SETTINGS_FILE, {})
                    currency = settings.get('currency', 'FCFA')
                    st.markdown(f"**{t('price')}:** {product['price']} {currency}")
                    st.markdown(f"**{t('category')}:** {product.get('category_fr' if st.session_state.language == 'fr' else 'category')}")
                    
                    if product.get('in_stock', True):
                        st.success("✓ " + t('in_stock'))
                        
                        qty = st.number_input(
                            t('quantity'),
                            min_value=1,
                            max_value=100,
                            value=1,
                            key=f"qty_{product['id']}"
                        )
                        
                        if st.button(t('add_to_cart'), key=f"add_{product['id']}", use_container_width=True):
                            if product['id'] in st.session_state.cart:
                                st.session_state.cart[product['id']]['quantity'] += qty
                            else:
                                st.session_state.cart[product['id']] = {
                                    'product': product,
                                    'quantity': qty
                                }
                            st.success("✓ " + ("Added to cart!" if st.session_state.language == 'en' else "Ajouté au panier!"))
                            st.rerun()
                    else:
                        st.error("✗ " + t('out_of_stock'))
                    
                    st.divider()

elif st.session_state.page == 'cart':
    st.header("🛒 " + t('your_cart'))
    
    if len(st.session_state.cart) == 0:
        st.info(t('empty_cart'))
        if st.button(t('continue_shopping')):
            st.session_state.page = 'products'
            st.rerun()
    else:
        # Display cart items
        settings = load_json(SETTINGS_FILE, {})
        currency = settings.get('currency', 'FCFA')
        total = 0
        
        for product_id, item in list(st.session_state.cart.items()):
            product = item['product']
            quantity = item['quantity']
            subtotal = product['price'] * quantity
            total += subtotal
            
            col1, col2, col3, col4 = st.columns([3, 1, 1, 1])
            with col1:
                st.write(f"**{product.get('name_fr' if st.session_state.language == 'fr' else 'name')}**")
            with col2:
                st.write(f"{product['price']} {currency}")
            with col3:
                st.write(f"x {quantity}")
            with col4:
                if st.button(t('remove'), key=f"remove_{product_id}"):
                    del st.session_state.cart[product_id]
                    st.rerun()
            
            st.divider()
        
        st.markdown(f"### {t('total')}: {total} {currency}")
        
        st.divider()
        
        # Customer information form
        st.subheader(t('customer_info'))
        
        with st.form("order_form"):
            customer_name = st.text_input(t('full_name') + " *", placeholder="John Doe")
            customer_phone = st.text_input(t('phone') + " *", placeholder="+237 XXX XXX XXX")
            customer_address = st.text_area(t('address') + " *", placeholder="Street, City, Region")
            customer_notes = st.text_area(t('additional_notes'), placeholder="Any special instructions...")
            
            submitted = st.form_submit_button(t('place_order'), use_container_width=True, type="primary")
            
            if submitted:
                if not customer_name or not customer_phone or not customer_address:
                    st.error("Please fill in all required fields (*)" if st.session_state.language == 'en' else "Veuillez remplir tous les champs obligatoires (*)")
                else:
                    # Create order
                    orders = load_json(ORDERS_FILE, [])
                    order_id = len(orders) + 1
                    
                    order = {
                        'id': order_id,
                        'date': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        'customer_name': customer_name,
                        'customer_phone': customer_phone,
                        'customer_address': customer_address,
                        'customer_notes': customer_notes,
                        'items': [
                            {
                                'product_name': item['product'].get('name_fr' if st.session_state.language == 'fr' else 'name'),
                                'price': item['product']['price'],
                                'quantity': item['quantity'],
                                'subtotal': item['product']['price'] * item['quantity']
                            }
                            for item in st.session_state.cart.values()
                        ],
                        'total': total,
                        'currency': currency,
                        'status': 'pending',
                        'seen': False,
                        'language': st.session_state.language
                    }
                    
                    orders.append(order)
                    save_json(ORDERS_FILE, orders)
                    
                    # Clear cart
                    st.session_state.cart = {}
                    
                    # Show success message
                    st.balloons()
                    st.markdown(f"""
                    <div class="success-message">
                        <h2>✓ {t('order_success')}</h2>
                        <h3>{t('order_id')}{order_id}</h3>
                        <p><strong>{t('total')}: {total} {currency}</strong></p>
                        <p>{t('payment_method')}</p>
                        <h4>🕐 {t('contact_message')}</h4>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    if st.button("← " + t('home')):
                        st.session_state.page = 'home'
                        st.rerun()

elif st.session_state.page == 'shopping_list':
    st.header("📝 " + t('custom_list_title'))
    st.write(t('custom_list_desc'))
    
    with st.form("shopping_list_form"):
        customer_name = st.text_input(t('full_name') + " *")
        customer_phone = st.text_input(t('phone') + " *")
        items_text = st.text_area(
            t('list_items') + " *",
            height=200,
            placeholder="Tomatoes\nOnions\nBread\n..." if st.session_state.language == 'en' else "Tomates\nOignons\nPain\n..."
        )
        additional_notes = st.text_area(t('additional_notes'))
        
        submitted = st.form_submit_button(t('submit_list'), use_container_width=True, type="primary")
        
        if submitted:
            if not customer_name or not customer_phone or not items_text:
                st.error("Please fill in all required fields (*)" if st.session_state.language == 'en' else "Veuillez remplir tous les champs obligatoires (*)")
            else:
                shopping_lists = load_json(SHOPPING_LISTS_FILE, [])
                
                shopping_list = {
                    'id': len(shopping_lists) + 1,
                    'date': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    'customer_name': customer_name,
                    'customer_phone': customer_phone,
                    'items': [item.strip() for item in items_text.split('\n') if item.strip()],
                    'notes': additional_notes,
                    'status': 'pending',
                    'seen': False,
                    'language': st.session_state.language
                }
                
                shopping_lists.append(shopping_list)
                save_json(SHOPPING_LISTS_FILE, shopping_lists)
                
                st.balloons()
                st.markdown(f"""
                <div class="success-message">
                    <h2>✓ {t('list_success')}</h2>
                    <h4>🕐 {t('contact_message')}</h4>
                </div>
                """, unsafe_allow_html=True)

elif st.session_state.page == 'admin':
    if not st.session_state.admin_logged_in:
        st.header("🔐 " + t('admin_login'))
        
        with st.form("admin_login_form"):
            password = st.text_input(t('password'), type="password")
            submitted = st.form_submit_button(t('login'), use_container_width=True)
            
            if submitted:
                settings = load_json(SETTINGS_FILE, {})
                if password == settings.get('admin_password', 'admin123'):
                    st.session_state.admin_logged_in = True
                    st.rerun()
                else:
                    st.error("Invalid password" if st.session_state.language == 'en' else "Mot de passe invalide")
    else:
        st.header("⚙️ " + t('admin') + " - " + ("Dashboard" if st.session_state.language == 'en' else "Tableau de Bord"))
        
        if st.button(t('logout')):
            st.session_state.admin_logged_in = False
            st.rerun()
        
        st.divider()
        
        # Admin tabs
        orders = load_json(ORDERS_FILE, [])
        shopping_lists = load_json(SHOPPING_LISTS_FILE, [])
        unseen_orders_count = len([o for o in orders if not o.get('seen', False)])
        unseen_lists_count = len([l for l in shopping_lists if not l.get('seen', False)])
        
        tab1, tab2, tab3, tab4 = st.tabs([
            "📦 " + t('manage_products'),
            "📋 " + t('view_orders') + (f" ({unseen_orders_count})" if unseen_orders_count > 0 else ""),
            "📝 " + t('view_shopping_lists') + (f" ({unseen_lists_count})" if unseen_lists_count > 0 else ""),
            "⚙️ " + t('settings')
        ])
        
        with tab1:
            st.subheader(t('manage_products'))
            
            products = load_json(PRODUCTS_FILE, [])
            
            # Add new product
            with st.expander("➕ " + t('add_product')):
                with st.form("add_product_form"):
                    col1, col2 = st.columns(2)
                    with col1:
                        new_name = st.text_input(t('product_name') + " (English)")
                        new_price = st.number_input(t('price'), min_value=0)
                        new_category = st.text_input(t('category') + " (English)")
                        new_desc = st.text_area(t('description') + " (English)")
                    with col2:
                        new_name_fr = st.text_input(t('product_name') + " (Français)")
                        new_in_stock = st.checkbox(t('in_stock'), value=True)
                        new_category_fr = st.text_input(t('category') + " (Français)")
                        new_desc_fr = st.text_area(t('description') + " (Français)")
                    
                    if st.form_submit_button(t('add_product')):
                        if new_name and new_price and new_category:
                            new_id = max([p['id'] for p in products], default=0) + 1
                            products.append({
                                'id': new_id,
                                'name': new_name,
                                'name_fr': new_name_fr or new_name,
                                'price': new_price,
                                'category': new_category,
                                'category_fr': new_category_fr or new_category,
                                'description': new_desc,
                                'description_fr': new_desc_fr or new_desc,
                                'in_stock': new_in_stock
                            })
                            save_json(PRODUCTS_FILE, products)
                            st.success("Product added!" if st.session_state.language == 'en' else "Produit ajouté!")
                            st.rerun()
            
            st.divider()
            
            # Edit/Delete products
            for product in products:
                with st.expander(f"{product['name']} - {product['price']} {load_json(SETTINGS_FILE, {}).get('currency', 'FCFA')}"):
                    with st.form(f"edit_product_{product['id']}"):
                        col1, col2 = st.columns(2)
                        with col1:
                            edit_name = st.text_input("Name (EN)", value=product.get('name', ''))
                            edit_price = st.number_input("Price", value=product.get('price', 0))
                            edit_category = st.text_input("Category (EN)", value=product.get('category', ''))
                            edit_desc = st.text_area("Description (EN)", value=product.get('description', ''))
                        with col2:
                            edit_name_fr = st.text_input("Name (FR)", value=product.get('name_fr', ''))
                            edit_in_stock = st.checkbox("In Stock", value=product.get('in_stock', True))
                            edit_category_fr = st.text_input("Category (FR)", value=product.get('category_fr', ''))
                            edit_desc_fr = st.text_area("Description (FR)", value=product.get('description_fr', ''))
                        
                        col_save, col_delete = st.columns(2)
                        with col_save:
                            if st.form_submit_button(t('save'), use_container_width=True):
                                product.update({
                                    'name': edit_name,
                                    'name_fr': edit_name_fr,
                                    'price': edit_price,
                                    'category': edit_category,
                                    'category_fr': edit_category_fr,
                                    'description': edit_desc,
                                    'description_fr': edit_desc_fr,
                                    'in_stock': edit_in_stock
                                })
                                save_json(PRODUCTS_FILE, products)
                                st.success("Updated!" if st.session_state.language == 'en' else "Mis à jour!")
                                st.rerun()
                        
                        with col_delete:
                            if st.form_submit_button(t('delete'), use_container_width=True, type="secondary"):
                                products = [p for p in products if p['id'] != product['id']]
                                save_json(PRODUCTS_FILE, products)
                                st.success("Deleted!" if st.session_state.language == 'en' else "Supprimé!")
                                st.rerun()
        
        with tab2:
            st.subheader(t('view_orders'))
            
            orders = load_json(ORDERS_FILE, [])
            
            if len(orders) == 0:
                st.info("No orders yet" if st.session_state.language == 'en' else "Aucune commande pour le moment")
            else:
                # Show notification for unseen orders
                unseen_orders = [o for o in orders if not o.get('seen', False)]
                if len(unseen_orders) > 0:
                    st.warning(f"🔴 {len(unseen_orders)} " + ("new order(s)! Review and mark as seen below." if st.session_state.language == 'en' else "nouvelle(s) commande(s)! Consultez et marquez comme vu ci-dessous."))
                    if st.button("✓ " + ("Mark all orders as seen" if st.session_state.language == 'en' else "Marquer toutes les commandes comme vues")):
                        for order in orders:
                            order['seen'] = True
                        save_json(ORDERS_FILE, orders)
                        st.rerun()
                
                # Display orders (newest first)
                for order in reversed(orders):
                    is_new = not order.get('seen', False)
                    
                    with st.expander(
                        f"{'🔴 NEW - ' if is_new else ''}{t('order_id')}{order['id']} - {order['customer_name']} - {order['total']} {order.get('currency', 'FCFA')}" +
                        f" - {order['date']}"
                    ):
                        st.write(f"**{t('customer')}:** {order['customer_name']}")
                        st.write(f"**{t('phone')}:** {order['customer_phone']}")
                        st.write(f"**{t('address')}:** {order['customer_address']}")
                        if order.get('customer_notes'):
                            st.write(f"**{t('additional_notes')}:** {order['customer_notes']}")
                        
                        st.divider()
                        st.write(f"**{t('items')}:**")
                        
                        for item in order['items']:
                            st.write(f"- {item['product_name']} x{item['quantity']} = {item['subtotal']} {order.get('currency', 'FCFA')}")
                        
                        st.markdown(f"### {t('total')}: {order['total']} {order.get('currency', 'FCFA')}")
                        st.info(t('payment_method'))
                        
                        st.divider()
                        
                        # Update order status
                        current_status = order.get('status', 'pending')
                        new_status = st.selectbox(
                            t('status'),
                            ['pending', 'confirmed', 'delivered'],
                            index=['pending', 'confirmed', 'delivered'].index(current_status),
                            key=f"status_{order['id']}"
                        )
                        
                        if new_status != current_status:
                            if st.button(t('save'), key=f"save_status_{order['id']}"):
                                order['status'] = new_status
                                save_json(ORDERS_FILE, orders)
                                st.success("Status updated!" if st.session_state.language == 'en' else "Statut mis à jour!")
                                st.rerun()
        
        with tab3:
            st.subheader(t('view_shopping_lists'))
            
            shopping_lists = load_json(SHOPPING_LISTS_FILE, [])
            
            if len(shopping_lists) == 0:
                st.info("No shopping lists yet" if st.session_state.language == 'en' else "Aucune liste pour le moment")
            else:
                # Show notification for unseen shopping lists
                unseen_lists = [l for l in shopping_lists if not l.get('seen', False)]
                if len(unseen_lists) > 0:
                    st.warning(f"🔴 {len(unseen_lists)} " + ("new shopping list(s)! Review and mark as seen below." if st.session_state.language == 'en' else "nouvelle(s) liste(s) de courses! Consultez et marquez comme vu ci-dessous."))
                    if st.button("✓ " + ("Mark all lists as seen" if st.session_state.language == 'en' else "Marquer toutes les listes comme vues")):
                        for slist in shopping_lists:
                            slist['seen'] = True
                        save_json(SHOPPING_LISTS_FILE, shopping_lists)
                        st.rerun()
                
                for slist in reversed(shopping_lists):
                    is_new = not slist.get('seen', False)
                    with st.expander(
                        f"{'🔴 NEW - ' if is_new else ''}List #{slist['id']} - {slist['customer_name']} - {slist['date']}"
                    ):
                        st.write(f"**{t('customer')}:** {slist['customer_name']}")
                        st.write(f"**{t('phone')}:** {slist['customer_phone']}")
                        
                        st.divider()
                        st.write(f"**{t('items')}:**")
                        for item in slist['items']:
                            st.write(f"- {item}")
                        
                        if slist.get('notes'):
                            st.write(f"**{t('additional_notes')}:** {slist['notes']}")
                        
                        st.divider()
                        
                        current_status = slist.get('status', 'pending')
                        new_status = st.selectbox(
                            t('status'),
                            ['pending', 'confirmed', 'delivered'],
                            index=['pending', 'confirmed', 'delivered'].index(current_status),
                            key=f"list_status_{slist['id']}"
                        )
                        
                        if new_status != current_status:
                            if st.button(t('save'), key=f"save_list_status_{slist['id']}"):
                                slist['status'] = new_status
                                save_json(SHOPPING_LISTS_FILE, shopping_lists)
                                st.success("Status updated!" if st.session_state.language == 'en' else "Statut mis à jour!")
                                st.rerun()
        
        with tab4:
            st.subheader(t('settings'))
            
            settings = load_json(SETTINGS_FILE, {})
            
            with st.form("settings_form"):
                new_password = st.text_input("Admin Password", value=settings.get('admin_password', 'admin123'), type="password")
                new_currency = st.text_input("Currency", value=settings.get('currency', 'FCFA'))
                new_phone = st.text_input("Contact Phone", value=settings.get('contact_phone', '+237 XXX XXX XXX'))
                new_email = st.text_input("Contact Email", value=settings.get('contact_email', 'contact@eyanglivraison.com'))
                
                if st.form_submit_button(t('save'), use_container_width=True):
                    settings.update({
                        'admin_password': new_password,
                        'currency': new_currency,
                        'contact_phone': new_phone,
                        'contact_email': new_email
                    })
                    save_json(SETTINGS_FILE, settings)
                    st.success("Settings updated!" if st.session_state.language == 'en' else "Paramètres mis à jour!")
                    st.rerun()
