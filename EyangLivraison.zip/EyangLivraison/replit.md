# Eyang Livraison - 24/7 Delivery Service

## Overview

Eyang Livraison is a Streamlit-based web application for a 24/7 delivery service focused on basic necessities. The application provides a simple e-commerce platform where customers can browse products, add items to their cart, place orders, and submit custom shopping lists. It features multi-language support (English and French) and includes an admin panel for managing the product catalog and orders.

The application uses a file-based JSON storage system for persisting data and is designed for quick deployment with minimal infrastructure requirements. Orders are fulfilled through direct customer contact (phone/agent callback) rather than automated payment processing, using a cash-on-delivery model.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Streamlit - A Python-based web framework for rapid application development
- **Rationale**: Streamlit was chosen for its simplicity and ability to create interactive web applications quickly without requiring separate frontend/backend codebases
- **Design Pattern**: Single-page application with multiple views managed through Streamlit's built-in page navigation
- **Multi-language Support**: Translation dictionary stored in-memory with language switching capability

### Data Storage
- **Solution**: File-based JSON storage
- **Structure**: Four separate JSON files for different data domains:
  - `products.json` - Product catalog with multi-language fields
  - `orders.json` - Customer orders
  - `shopping_lists.json` - Custom shopping list submissions
  - `settings.json` - Application configuration and admin credentials
- **Rationale**: JSON file storage was chosen for simplicity and portability, suitable for a lightweight application with moderate data volumes
- **Trade-offs**: 
  - Pros: No database setup required, easy to backup, human-readable
  - Cons: Limited scalability, no built-in concurrency control, potential performance issues with large datasets
- **Data Directory**: All data files are stored in a `data/` directory at the application root

### Application State Management
- **Session State**: Leverages Streamlit's session state for managing shopping cart and user interactions
- **Product Data**: Products include multi-language fields (name, category, description) supporting English and French
- **Currency**: Prices stored in FCFA (Central African CFA franc)

### Authentication & Authorization
- **Admin Access**: Simple password-based authentication stored in settings.json
- **Customer Access**: No authentication required for browsing and ordering
- **Security Note**: Current implementation uses plaintext password storage in JSON, suitable for development but should be upgraded for production

### Notification System
- **Order Notifications**: New orders are marked with a `seen: false` flag in orders.json
- **Shopping List Notifications**: New custom lists are marked with a `seen: false` flag in shopping_lists.json
- **Admin Interface**: 
  - Red badges show count of unseen orders and lists in navigation menu
  - Warning banners appear in admin tabs when unseen items exist
  - "Mark all as seen" button allows bulk clearing of notifications
- **Persistence**: Notification state persists across sessions and page reloads via JSON file storage

### Business Logic
- **Order Fulfillment Model**: Cash-on-delivery with agent callback system
- **Customer Contact**: Orders trigger agent notification to contact customer within 5 minutes
- **Custom Shopping Lists**: Customers can submit requests for items not in the catalog
- **Inventory Management**: Simple in-stock/out-of-stock boolean flag per product

## External Dependencies

### Python Libraries
- **streamlit**: Core web application framework
- **pandas**: Data manipulation and display (for tables and data structures)
- **json**: JSON file operations for data persistence
- **datetime**: Timestamp management for orders and submissions
- **os**: File system operations and path management

### Third-party Services
- **Contact System**: Phone-based agent contact (phone number configured in settings.json)
- **Email**: Email address configured for customer support (contact@eyanglivraison.com)

### Data Schema Notes
- Product schema includes multi-language support with separate fields for English (`name`, `category`, `description`) and French (`name_fr`, `category_fr`, `description_fr`)
- All monetary values stored as integers representing FCFA
- No external payment gateway integration - uses cash-on-delivery model
- No external database or cloud storage services currently integrated